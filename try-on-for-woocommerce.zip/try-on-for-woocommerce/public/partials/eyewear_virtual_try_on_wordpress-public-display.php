<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://www.dugudlabs.com
 * @since      1.0.0
 *
 * @package    Eyewear_virtual_try_on_wordpress
 * @subpackage Eyewear_virtual_try_on_wordpress/public/partials
 */
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

		//wp_enqueue_script('jquery');
?>
 <div class="container" id="contenainer">
    <div class="modal fade" id="TryOnModal" data-backdrop="false" role="dialog" style="z-index: 10000000;margin-top: 45px;">
        <div class="modal-dialog" id="TryOnModal-dialog" >
            <div class="modal-content try_on_popup">
                <div class="modal-header" style="padding-top: 5px;padding-left: 5px;padding-bottom: 0px;">
                    <div class="row" style="margin-bottom:0px;">
                        <div class="col-md-12 col-lg-12  col-xs-12  col-sm-12">
                            <input  title="Slider to rotate jewellery" type="range" min="-100" max="180" value="0" oninput="rotate_jewelfit(this.value)" class="slider" id="roateRange">
                            <input title="Slider to resize jewellery" type="range" min="-22" max="30" value="0" step="1" onchange="zoom_out(this.value)" class="slider" id="resizeRange">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                    </div>
                </div>
                <div class="modal-body" id="modal_body">
                    <div class="row" style="margin-bottom:0px;">
                        <div class="col-lg-12 col-xs-12 col-sm-12">
                            <div class="row" style="margin-bottom:0px;">
                                <div class="col-lg-12  col-md-12 col-xs-12 col-sm-12">
                                    <div id="image_download" class="row" >
                                        <div id="galssimagediv" >
                                            <img  id="galssimage" src=""  class="img-responsive img-thumbnail fixed_images"  >
                                        </div>
                                        <img style="width: 100%;"  src="<?php echo plugin_dir_url(__FILE__).'/images/man_face.jpg' ?>" id="imageCanvas" class="img-responsive img-thumbnail fixed_images" alt="Cinque Terre">
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <?php echo "<a class='btn btn-info' id='addtocartlink' href=''><span class='glyphicons glyphicons-shoping-cart'></span>Add to cart</a>";?> 
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>


