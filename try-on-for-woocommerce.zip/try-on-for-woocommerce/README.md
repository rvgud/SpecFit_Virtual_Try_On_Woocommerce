﻿# SpecFit-Virtual Try On Woocommerce
 Virtual Eyewear try On plugin for Wordpress/Wocommerce
Contributors: dugudlabs
Donate link: https://dugudlabs.com/specfit
Tags: Virtual Eye Wear,Virtual Mirror,Try On
Requires at least: 3.3
Tested up to: 5.4
Requires php: 5.0 or later
Stable tag: 1.0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Vitual EyeWear Try-On SpecFit allows customers to virtually try eye wears products on their face before buying it.

== Description ==

Vitual EyeWear Try-On SpecFit allows customers to virtually try eye wears products on their face before buying it.

== Standard Version ==

- Upload Unlimited Eyewears
- Add to cart button
- 360 degree rotation of Eyewear
- Resizable Eyewear

== Premium Version ==

- Available at[SpecFit](https://www.dugudlabs.com/specfit)
- Upload Unlimited Eyewears
- Add to cart button
- 360 degree rotation of Eyewear
- Resizable Eyewear
- Customers can upload their face image
- Customers can capture their face image
- Customers can Download and Share their Try On image
- Side View option
- Free Setup of 10 eyewears

== Installation ==

1. Upload `try_on_woocommerece.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to products page.
4. Edit the Eye wear product.
5. Scroll down and click on set try on image.
6. Select a transparent front image of eye wear.
7. View Product.
8. A try on button will be there.
9. Click on the button and thats it.

== Video guide ==

[youtube https://www.youtube.com/watch?v=HQian7LDMz0 ]


== Frequently asked questions ==

= Is this require woocommerce to be installed =

Yes.

= How it works? =

Our Development team’s main focus was to make this plugin more easy to use and customize.So we have designed this plugin in a way that only one step can reach your requirements.You just have to go to product page->Edit->Set try on image. That’s it. It will automatically render a try on button on that product.

= What is Try on image? =

To render try on button on any product detail page you will have to set a try on image via product edit page or create new product page.This try on image is a simple front facing view of your eyewear product.This should be a transparent image.Image dimensions and guide to make a perfect Try On image is available at Product edit page only.

= Does this plugin automatically create a transparent image of eyewear?  =

No,For every product you will have to upload a Try On image which will be rendered on try on pop up.This image should be transparent background image.

== Screenshots ==

1. Set Try On Image
2. Try On pop up

== Changelog ==

- Major Bug Fixes.
- Option to troubleshoot

== Upgrade notice ==

NA
