<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.dugudlabs.com
 * @since      1.0.0
 *
 * @package    Eyewear_virtual_try_on_wordpress
 * @subpackage Eyewear_virtual_try_on_wordpress/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Eyewear_virtual_try_on_wordpress
 * @subpackage Eyewear_virtual_try_on_wordpress/includes
 * @author     DugudLabs <ravindrashekhawat5876@gmail.com>
 */
class Eyewear_virtual_try_on_wordpress_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		global $wpdb;
		$create_table_query = "
				CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}specfit_options` (
				  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				  `name` text NOT NULL,
				  `value` text NOT NULL,
				  PRIMARY KEY (id)
				)AUTO_INCREMENT=100  ENGINE=MyISAM  DEFAULT CHARSET=utf8;
		";
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $create_table_query );
		$tableName =$wpdb->prefix.'specfit_options';
		$wpdb->insert($tableName, array(
			"id" => '100',
			"name" => 'include_bootstrap',
			"value" => 'no'
		 ), array( '%d', '%s', '%s' ) );
	}

}
