<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://www.dugudlabs.com
 * @since      1.0.0
 *
 * @package    Eyewear_virtual_try_on_wordpress
 * @subpackage Eyewear_virtual_try_on_wordpress/admin/partials
 */
global $wpdb;
if(isset($_POST['bootstrap_enable'])){ //check if form was submitted
  $bootstrap_enable = $_POST['bootstrap_enable']; 
  $tableName =$wpdb->prefix.'specfit_options';
  if($bootstrap_enable == 'on'){
    $checked="checked";
    $wpdb->update( $tableName, array( 
      "value" => "yes"),
       array( 'name' => "include_bootstrap" ), array( '%s'), array( '%s' ) );
  }
  else{
    $wpdb->update( $tableName, array( 
      "value" => "no"),
       array( 'name' => "include_bootstrap" ), array( '%s'), array( '%s' ) );
  }
}
else{
    $bootstrap_enable=$wpdb->get_results ( "
    SELECT value 
    FROM  ".$wpdb->prefix."specfit_options where name='include_bootstrap'" );
    
    if($bootstrap_enable[0]!=null && $bootstrap_enable[0]->value == 'yes'){
        $checked="checked";
      }
      else{
        $checked="";
      }
}  ?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<html>
	<head>
		<style>
		.spacer.green, .section.green h4 {
    color: #fff;
}
input[type=text], select, textarea {
  width: 100%; /* Full width */
  padding: 12px; /* Some padding */  
  border: 1px solid #ccc; /* Gray border */
  border-radius: 4px; /* Rounded borders */
  box-sizing: border-box; /* Make sure that padding and width stays in place */
  margin-top: 6px; /* Add a top margin */
  margin-bottom: 16px; /* Bottom margin */
  resize: vertical /* Allow the user to vertically resize the textarea (not horizontally) */
}

/* Style the submit button with a specific background color etc */
input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

/* When moving the mouse over the submit button, add a darker green color */
input[type=submit]:hover {
  background-color: #45a049;
}

/* Add a background color and some padding around the form */
.container {
  border-radius: 5px;
  padding: 20px;
}			
.spacer.green, .section.green {
    background: #c7efe8;
}
			.aligncenter {
    text-align: center;
}

.aligncenter {
    clear: both;
    display: block;
    margin: 0 auto;
}
			h2.pagetitle {
    color: #00746c;
    font-size: 46px;
}

h2 {
    font-size: 30px;
    margin-bottom: 20px;
}
h1, h2, h3, h4, h5, h6 {
    font-weight: 400;
    color: #312f2b;
    line-height: 1.1em;
    font-family: 'Open Sans', Arial, sans-serif;
}
.btn-primary {
    color: #fff;
    background-color: #1c756c;
    border-color: #2e6da4;
}
button, select {
    text-transform: none;
}
.btn {
    display: inline-block;
    margin-bottom: 0;
    font-weight: 400;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    background-image: none;
    border: 1px solid transparent;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    border-radius: 4px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}		
		</style>
        <script>
        function update_text(checkbox){
            if (checkbox.checked)
            {
                document.getElementById("textbox").value = "on";
            }
            else{
                document.getElementById("textbox").value = '';
            }
        }
        </script>
	</head>
<body>
<div class="container" style="background-color: #fff;">
    <h2>
    Specfit Admin Options
    </h2>
        <form action="" method="post">
        <input type="text" id="textbox" name="bootstrap_enable" style="display:none"> 
        <div class="checkbox">
            <label><input id="myCheck" <?php echo $checked; ?> onclick="update_text(this);" type="checkbox"> <b>Include bootstrap and jquery </b>(Check if your pop is not showing on product page.)</label>
        </div></br>
        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
        </form>
</div>

  <section id="faq_spacer" class="spacer green">
<div class="container">
<div class="row">
<div class="span12 aligncenter flyUp">
<h2 class="pagetitle"><strong>Premium Plans</strong></h2>
<p><img class="size-full wp-image-29 aligncenter" src="<?php echo plugin_dir_url( __FILE__ ); ?>images/SpecFit.png" alt="Specfit : Virtual Try On WordPress Plugin " width="80" height="105"></p>
</div>
</div>
</div>
</section>
	<a href="https://dugudlabs.com/specfit" target="_blank"><img  width="100%" src="<?php echo plugin_dir_url( __FILE__ ); ?>images/plans.png"></a>
  <section id="faq_spacer" class="spacer green">
<div class="container">
<div class="row">
<div class="span12 aligncenter flyUp">
<h2 style="margin-top: 0px;" class="pagetitle"><strong>Excited to know more?</strong></h2>
	<h3>Email us: ravinstra5876@gmail.com</h3>
    <h3>WhatsApp: Ravindra Singh - +918386005876</h3>
<p><img class="size-full wp-image-29 aligncenter" src="<?php echo plugin_dir_url( __FILE__ ); ?>images/SpecFit.png" alt="Specfit : Virtual Try On WordPress Plugin " width="80" height="105"></p>
</div>
</div>
</div>
</section>
 </body>
</html>
